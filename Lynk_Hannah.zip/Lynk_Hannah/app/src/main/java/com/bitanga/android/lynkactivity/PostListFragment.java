package com.bitanga.android.lynkactivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class PostListFragment extends Fragment {
    private static final String TAG = "check";

    //actually has the post recycler view
    private RecyclerView mPostRecyclerView;
    private PostAdapter mAdapter;
    private int mPostPosition;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_post_list, container, false);
        mPostRecyclerView = (RecyclerView) view.findViewById(R.id.post_recycler_view);
        mPostRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Post post = new Post();
                PostLab.get(getContext()).addPost(post);
                Intent intent = PostPagerActivity
                        .newIntent((getContext()), post.getId());
                startActivity(intent);

            }
        });
        updateUI();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        updateUI();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_post_list, menu);

    }


    private void updateUI() {
        PostLab postLab = PostLab.get(getActivity());
        List<Post> posts = postLab.getPosts();

        if(mAdapter == null) {
            mAdapter = new PostAdapter(posts);
            mPostRecyclerView.setAdapter(mAdapter);
        } else {
            mAdapter.setPosts(posts);
            mAdapter.notifyDataSetChanged();
        }
    }

    private class PostHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private Post mPost;
        private TextView mContentTextView;
        private ImageView mPhotoImageView;
        private ImageButton mLike;
        private ImageButton mComment;
        private ImageButton mFlag;
        private TextView mTimePostedTextView;

        private int numOfTimesFlagged;

        public PostHolder(LayoutInflater inflater, ViewGroup parent, int viewType) {
            super(inflater.inflate(viewType, parent, false));
            itemView.setOnClickListener(this);

            mContentTextView = (TextView) itemView.findViewById(R.id.post_content);
            mPhotoImageView = (ImageView) itemView.findViewById(R.id.post_photo);
            mLike = (ImageButton) itemView.findViewById(R.id.imageButton2);
            mComment = (ImageButton) itemView.findViewById(R.id.imageButton);
            mFlag = (ImageButton) itemView.findViewById(R.id.imageButton3);
            mTimePostedTextView = (TextView) itemView.findViewById(R.id.timestamp);
            numOfTimesFlagged = 0;
        }

        public void bind(Post post) {
            mPost = post;
            mContentTextView.setText(mPost.getContent());
            /**set mPhotoImageView with image (maybe with file like did in PostFragment?**/
            mLike.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast toast = Toast.makeText(getContext(),
                            "You liked this post!",
                            Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.BOTTOM, 1, 1);
                    toast.show();
                }
            });

            //need to get current time minus post time
            //post time should be set in PostFragment
            Date currentTime = Calendar.getInstance().getTime();
            mPost.setTimePosted(mPost.getTimePosted());
            DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
            mTimePostedTextView.setText(dateFormat.format(mPost.getTimePosted()));


            mComment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast toast = Toast.makeText(getContext(),
                            "You chose to comment on this post!",
                            Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.BOTTOM, 1, 1);
                    toast.show();
                    //get post id like when going to make comment?
                    //go to comment activity/fragment
                    //start the intent
                }
            });
            mFlag.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast toast = Toast.makeText(getContext(),
                            "You flagged this post!",
                            Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.BOTTOM, 1, 1);
                    toast.show();
                    numOfTimesFlagged++;
                    if(numOfTimesFlagged == 3) {
                        Toast.makeText(getContext(),
                                "Consider this post BANNED!",
                                Toast.LENGTH_SHORT).show();
//                        mFlag.setEnabled(false);
                        PostLab.get(getActivity()).deletePost(mPost);
                        updateUI();
                    }
                }
            });

            File mPhotoFile = PostLab.get(getActivity()).getPhotoFile(mPost);
            if (mPhotoImageView != null && mPhotoFile.exists()) {
                Bitmap bitmap = PictureUtils.getScaledBitmap(
                        mPhotoFile.getPath(), getActivity());
                mPhotoImageView.setImageBitmap(bitmap);
            } else {
                mPhotoImageView.setVisibility(View.GONE);
            }

        }

        @Override
        public void onClick(View view) {
            mPostPosition = getAdapterPosition();
            Intent intent = PostPagerActivity.newIntent(getActivity(), mPost.getId());
            startActivity(intent);
        }
    }

    private class PostAdapter extends RecyclerView.Adapter<PostHolder> {
        private List<Post> mPosts;

        public PostAdapter(List<Post> posts) {
            mPosts = posts;
        }

        @Override
        public PostHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());

            return new PostHolder(layoutInflater, parent, viewType);
        }

        @Override
        public void onBindViewHolder(PostHolder holder, int position) {
            Post post = mPosts.get(position);
            holder.bind(post);
        }

        @Override
        public int getItemCount() {
            return mPosts.size();
        }

        public void setPosts(List<Post> posts) {
            mPosts = posts;
        }

        @Override
        public int getItemViewType(int position) {
            return R.layout.list_item_post;
        }

    }
}
