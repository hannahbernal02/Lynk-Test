package com.bitanga.android.lynkactivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;

import java.util.List;
import java.util.UUID;

public class PostPagerActivity extends AppCompatActivity {
    private static final String EXTRA_POST_ID =
            "com.hbernal.android.Lynk";

    private ViewPager mViewPager;
    private List<Post> mPosts;

    public static Intent newIntent(Context packageContext, UUID postId) {
        Intent intent = new Intent(packageContext, PostPagerActivity.class);
        intent.putExtra(EXTRA_POST_ID, postId);
        return intent;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_pager);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        UUID postId = (UUID) getIntent()
                .getSerializableExtra(EXTRA_POST_ID);

        mViewPager = (ViewPager) findViewById(R.id.post_view_pager);

        mPosts = PostLab.get(this).getPosts();
        FragmentManager fragmentManager = getSupportFragmentManager();
        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) {
            @Override
            public Fragment getItem(int position) {
                Post post = mPosts.get(position);
                return PostFragment.newInstance(post.getId());
            }

            @Override
            public int getCount() {
                return mPosts.size();
            }
        });

        for (int i = 0; i < mPosts.size(); i++) {
            if (mPosts.get(i).getId().equals(postId)) {
                mViewPager.setCurrentItem(i);
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
//            super.onBackPressed();
        //alert dialog (are you sure?)
//        AlertDialog alertDialog = new AlertDialog.Builder(PostPagerActivity.this).create();
//        alertDialog.setTitle("Alert");
//        alertDialog.setMessage("Alert message to be shown");
//        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
//                new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        dialog.dismiss();
//                    }
//                });
//        alertDialog.show();

        new AlertDialog.Builder(this)
                .setTitle("Are you sure you want to leave this page?")
                .setMessage("Your post will be deleted if you choose to leave")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //delete post here
                        PostLab.get(getBaseContext()).deletePost(mPosts.get(mViewPager.getCurrentItem()));
                        finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }

}
