package com.bitanga.android.lynkactivity;

import android.widget.ImageView;

import java.util.Date;
import java.util.UUID;

public class Post {

    private UUID mId;
    private String mContent;

    private int mComments;
    private int mLikes;

    private ImageView mPostPhoto;
//    private User user;
    private Date mTimePosted;


    public Post() {
        this(UUID.randomUUID());
    }

    public Post(UUID id) {
        mId = id;
    }

    public UUID getId() {return mId;}

    public String getContent() {
        return mContent;
    }

    public void setContent(String content) {
        mContent = content;
    }

    /*returns number of comments and likes*/
    public int getComments() {
        return mComments;
    }

    public void setComments(int comments) {
        mComments = comments;
    }

    public int getLikes() {
        return mLikes;
    }

    public void setLikes(int likes) {
        mLikes = likes;
    }

    public Date getTimePosted() {
        return mTimePosted;
    }

    public void setTimePosted(Date timePosted) {
        mTimePosted = timePosted;
    }

    public String getPhotoFilename() {
        return "IMG_" + getId().toString() + ".jpg";
    }
}
