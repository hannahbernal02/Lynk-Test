package com.bitanga.android.lynkactivity;

import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PostLab {
    private static PostLab sPostLab;

    //use list for now
    private List<Post> mPosts;
    private Context mContext;
    //firebase database

    public static PostLab get(Context context) {
        if (sPostLab == null) {
            sPostLab = new PostLab(context);
        }
        return sPostLab;
    }

    public PostLab(Context context) {
        mContext = context.getApplicationContext();
        //database = post base helper with context and get writable db
        //for now
        mPosts = new ArrayList<>();
    }

    //add post
    public void addPost(Post p) {
        mPosts.add(p);
    }

    //delete post
    public void deletePost(Post p) {
        mPosts.remove(p);
    }

    public List<Post> getPosts() {
        //for now
        return mPosts;
    }

    public Post getPost(UUID id) {
        for (Post post : mPosts) {
            if (post.getId().equals(id)) {
                return post;
            }
        }
        return null;
    }

    public File getPhotoFile(Post post) {
        File filesDir = mContext.getFilesDir();
        return new File(filesDir, post.getPhotoFilename());
    }

    //update post?
}
